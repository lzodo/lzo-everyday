import React, { PureComponent } from 'react'
import "./Home.css"

export class Home extends PureComponent {
  render() {
    return (
      <div className='section'>
        <div className='title'>Home的标题</div>
      </div>
    )
  }
}

export default Home