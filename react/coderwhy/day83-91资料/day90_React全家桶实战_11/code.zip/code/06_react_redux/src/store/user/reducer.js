
const initialState = {
  userInfo: { nickname: "刘军老师", level: 100 }
}

function reducer(state = initialState, action) {
  return state
}

export default reducer
