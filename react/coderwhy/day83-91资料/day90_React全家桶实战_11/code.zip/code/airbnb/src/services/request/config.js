export const BASE_URL = "http://codercba.com:1888/airbnb/api"
export const TIMEOUT = 10000

