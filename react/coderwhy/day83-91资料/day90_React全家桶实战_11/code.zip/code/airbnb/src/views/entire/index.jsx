import React, { memo } from 'react'

const Entire = memo(() => {
  return (
    <div>Entire</div>
  )
})

export default Entire