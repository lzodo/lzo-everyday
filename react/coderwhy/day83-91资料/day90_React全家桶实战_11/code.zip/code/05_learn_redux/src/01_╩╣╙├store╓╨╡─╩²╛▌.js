const store = require("./store")

console.log(store.getState())
