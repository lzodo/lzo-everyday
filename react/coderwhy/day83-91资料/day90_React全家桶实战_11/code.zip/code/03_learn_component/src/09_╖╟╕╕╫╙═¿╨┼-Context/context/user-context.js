import React from "react"

// 1.创建一个Context
const UserContext = React.createContext()

export default UserContext
