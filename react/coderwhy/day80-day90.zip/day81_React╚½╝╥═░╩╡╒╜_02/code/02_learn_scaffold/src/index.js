import ReactDOM from "react-dom/client"

import App from "./App"

// 编写React代码, 并且通过React渲染出来对应的内容
const root = ReactDOM.createRoot(document.querySelector("#root"))
root.render(<App/>)
