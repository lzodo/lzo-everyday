import React from "react"

class App extends React.Component {
  render() {
    return <h2>哈哈哈</h2>
  }
}

export default App
