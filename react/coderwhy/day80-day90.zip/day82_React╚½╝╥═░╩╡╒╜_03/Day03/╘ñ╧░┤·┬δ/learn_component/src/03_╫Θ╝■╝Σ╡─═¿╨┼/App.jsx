import React, { Component } from 'react'
import Header from "./Header"
import Footer from './Footer'
import Main from './Main'

class App extends Component {
  constructor() {
    super()
    this.state = {
      title: "Header的标题"
    }
  }

  headerClick() {
    console.log("----");
  }

  render() {
    const {title} = this.state

    return (
      <div>
        <Header title={title} headerClick={() => this.headerClick()}/>
        <Main/>
        <Footer/>
      </div>
    )
  }
}

export default App