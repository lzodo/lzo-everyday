import React, { Component } from 'react'
import TabControl from './TabControl'

class App extends Component {
  constructor() {
    super()
    this.state = {
      titles: ["衣服", "鞋子", "帽子"],
      friend: {
        name: "kobe",
        age: 30
      }
    }
  }

  render() {
    const { titles, friend } = this.state

    return (
      <div>
        <TabControl titles={titles} {...friend}>
          { (title) => <button>{title}</button> }
        </TabControl>
      </div>
    )
  }
}

export default App