import { UserContext } from "./context"

function Recommend(props) {
  return (
    <div>
      <span>Recommend</span>
      <UserContext.Consumer>
        {
          value => {
            return <span>{value.name}</span>
          }
        }
      </UserContext.Consumer>
    </div>
  )
}

export default Recommend
