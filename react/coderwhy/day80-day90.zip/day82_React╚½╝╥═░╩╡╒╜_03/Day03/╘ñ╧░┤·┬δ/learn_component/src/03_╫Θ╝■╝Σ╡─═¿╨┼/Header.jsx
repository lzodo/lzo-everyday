import React, { Component } from 'react'

export class Header extends Component {
  // constructor(props) {
  //   super(props)

  //   this.state = {}
  // }

  render() {
    const { title, headerClick } = this.props
    return (
      <div onClick={headerClick}>Header: {title}</div>
    )
  }
}

export default Header