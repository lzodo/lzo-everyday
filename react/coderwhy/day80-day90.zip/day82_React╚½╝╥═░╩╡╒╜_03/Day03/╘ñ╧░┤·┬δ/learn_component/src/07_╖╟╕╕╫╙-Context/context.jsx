import React from 'react'

export const UserContext = React.createContext({ name: "kobe", age: 30 })