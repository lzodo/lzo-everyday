import React, { Component } from 'react'

class HelloWorld extends Component {
  shouldComponentUpdate(prevProps, prevState) {
    return prevProps.message !== this.props.message
  }

  render() {
    console.log("Hello World render")
    const { message } = this.props

    return (
      <div>
        <h2>Hello World: {message}</h2>
        <ul>
          <li>Hello World item1</li>
          <li>Hello World item2</li>
          <li>Hello World item3</li>
        </ul>
      </div>
    )
  }
}

export default HelloWorld