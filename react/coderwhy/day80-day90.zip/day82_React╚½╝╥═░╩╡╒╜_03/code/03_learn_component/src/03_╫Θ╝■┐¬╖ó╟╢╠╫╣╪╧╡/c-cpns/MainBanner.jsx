import React, { Component } from 'react'

export class MainBanner extends Component {
  render() {
    return (
      <div>
        <h2>封装一个轮播图</h2>
      </div>
    )
  }
}

export default MainBanner